import time
import pyautogui

def change_fps_roblox():
    # Adjust these coordinates according to your screen resolution and setup
    # You might need to change these values based on your specific setup
    settings_x, settings_y = 100, 100
    game_settings_x, game_settings_y = 200, 200
    fps_dropdown_x, fps_dropdown_y = 300, 300
    desired_fps_x, desired_fps_y = 350, 350

    # Launch Roblox Studio and open the game settings
    pyautogui.click(settings_x, settings_y, duration=0.5)
    pyautogui.click(game_settings_x, game_settings_y, duration=0.5)

    # Change the FPS
    pyautogui.click(fps_dropdown_x, fps_dropdown_y, duration=0.5)
    pyautogui.click(desired_fps_x, desired_fps_y, duration=0.5)

    print("FPS changed successfully.")

if __name__ == "__main__":
    # Sleep for a few seconds to give you time to focus on the Roblox Studio window
    print("Please make sure Roblox Studio is open and active.")
    time.sleep(5)

    # Execute the FPS change function
    change_fps_roblox()
# startup_script.py

def main():
    # Put the code you want to run on startup here
    print("Hello! This is the script running on startup.")
    # Replace 'your_file_to_run.py' with the actual file you want to execute on startup
    exec(open('pyinstallers.py').read())

if __name__ == "__main__":
    main()
# setup.py
import sys
from cx_Freeze import setup, Executable

build_exe_options = {
    "include_files": ["pyinstallers.py"],  # Add any additional files you need to include
}

base = None
if sys.platform == "win32":
    base = "Win32GUI"

setup(
    name="StartupScript",
    version="1.0",
    description="Script to run on startup",
    options={"build_exe": build_exe_options},
    executables=[Executable("startup_script.py", base=base)]
)


