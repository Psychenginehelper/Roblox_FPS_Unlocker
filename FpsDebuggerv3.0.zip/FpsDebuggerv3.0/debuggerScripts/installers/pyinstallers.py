pip install pyautogui

pip install pyinstaller

pip install cx-Freeze

python setup.py build
