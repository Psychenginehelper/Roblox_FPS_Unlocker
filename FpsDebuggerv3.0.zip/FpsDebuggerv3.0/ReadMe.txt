Roblox FPS Debugger is not a virus, it is triggered as a false positive do to it having to inject within Roblox to change the FPS, and stop lag. 
Roblox FPS Debugger is Free, no credit card or free trial needed. This was made to help get rid of lag, and make a more satisfying experience for Roblox players. The "ReadMe" File is only present to official download of RFPSD (Roblox FPS Debugger)
Have Fun, Buddy!
You are accessing a beta, but stable version of 1.3. Report any bugs to rfpsd@gmail.com